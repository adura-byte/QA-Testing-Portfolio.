# QA Testing Portfolio — adura-byte

Welcome to my QA Testing Portfolio. This repository documents my learning and practical exercises in software quality assurance, with a focus on manual testing, test case design, defect reporting, and clear test documentation.

> **Portfolio status:** Beginner practice portfolio. The test scenarios and defect examples in this repository are learning exercises. They are not claims of defects discovered in a production system unless explicitly stated and verified.

## About me
I am building practical skills in Quality Assurance (QA), including:
- Manual and functional testing
- Test scenario and test case design
- Positive, negative, and boundary testing
- Defect/bug reporting
- Test execution and summary reporting
- Attention to detail and clear communication

## Projects

### 1. Login page testing
A practice exercise covering login validation and common user inputs.

- [Test cases](test-cases/login-test-cases.csv)
- [Sample bug reports](bug-reports/sample-login-bugs.md)
- [Test summary](test-summary/login-test-summary.md)


### 2. VB Bank Web Application Testing — Test Case Documentation

This is a hands-on manual testing project I personally created for the VB Bank demo web application. The document contains **62 test cases** covering registration/onboarding, login, dashboard, transfers, bill payments, cards, loans, and transaction history. Each test case includes a scenario, precondition, steps, expected result, actual result, and execution status.

- **Test case document (PDF):** [View my VB Bank test cases](projects/vb-bank-testing/Olusanya-Samson-VB-Bank-Test-Cases.pdf)
- **Application tested:** [VB Bank Demo](https://vb-bank-demo.vercel.app/)
- **Google Sheets version:** [Open my original test-case spreadsheet](https://docs.google.com/spreadsheets/d/1jJf6PvpAw1qk6EMSt-sWyERfD7JcqsJVv-5TThTEwUk/edit?pli=1&gid=0#gid=0)

The test results recorded in the document include both passed and failed test cases. The failed cases are documented observations from this testing exercise; findings should be revalidated if the application changes.

## How I report defects
Each bug report captures:
- Bug ID and title
- Environment
- Preconditions
- Steps to reproduce
- Expected result
- Actual result
- Severity and priority
- Evidence (when available)

## Tools
- GitHub for version control and portfolio presentation
- Spreadsheet/CSV for test cases
- Postman and browser developer tools as I expand this portfolio

## Contact
GitHub: https://github.com/adura-byte

---
I welcome feedback and opportunities to learn, collaborate, and improve my QA skills.
